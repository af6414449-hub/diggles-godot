proc localize {textString} {
	set g_lang_string {"neededMaterial" "Rohstoffe" "Waffen" "Manager" "settings" "sammleErfahrungin"
		 "infoStringManager"
		 "enable" "disable" "Equipment" "NewUserTask" "currentTaskList" "TransferLocations" "Remove_exchange_place"
		 "ItemsInWorld" "WennAllesFertig" "sofort"
		 "Niemand" "uebergibt" "an" "niemanden" "bei" "hebt" "nichts" "auf" "legt" "ab" "ausfuehren"}
	
	set g_lang_de_string {"ben�tigtes Material" "Rohstoffe" "Waffen" "Manager" "Einstellungen" "sammle Erfahrung in"
		"Hier kann man einem Zwerg die Anweisung geben, in welchem Gebiet er Erfahrungen sammeln soll. Dies geschieht, indem der Produktionsmanager den Zwerg derjenigen Produktionsst�tte zuweist, f�r die es die meisten Erfahrungspunkte gibt." 
		"aktivieren" "deaktivieren" "Ausr�stung" "Neuer Task" "Aktuelle Aufgaben" "�bergabeorte" "Entferne_�bergabeort"
		"Items die frei herumliegen" "Wenn alles fertig" "sofort"
		 "Niemand" "�bergibt" "an" "niemanden" "bei" "hebt" "nichts" "auf"  "legt" "ab" "Ausf�hren"}
	
	set g_lang_en_string {"necessary material" "Resources" "Weapons" "Manager" "Settings" "gain experience in"
		"You can define a field of experience for each dwarf. The ProductionManager will try to assign the dwarf to that production site which gives the most experience gain."
		"enable" "disable" "Equipment" "New task" "Current tasks"  "Transfer locations" "Remove_transfer_location"
		"Items which lie around in the world" "When ready" "instant"
		 "Nobody" "hands over" "to" "nobody" "at" "picks" "nothing" "up"  "puts" "down" "Execute"}
		
	set idx [lsearch $g_lang_string $textString]
	
	if {[locale] == "de"} {
		if {$idx >= 0} {
			return [lindex $g_lang_de_string $idx]
		} else {
			return "???"
		}
	} else {
		if {$idx >= 0} {
			return [lindex $g_lang_en_string $idx]
		} else {
			return "???"
		}
	}
}
