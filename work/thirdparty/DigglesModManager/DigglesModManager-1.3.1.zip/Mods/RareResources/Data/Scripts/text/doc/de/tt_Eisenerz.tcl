textwin clear
call /scripts/misc/onlinehelputils.tcl
ohlp_initstyle
textwin print "/(is10)/(ildata/gui/icons/Eisenerz.tga)"

// ---- text starts here - do not change anything above this line ---

ohlp_ttheadlinestyle
textwin print "Eisenerz"
ohlp_tttextbodystyle
textwin print "Mit harter Arbeit und guten Schmelzk�nsten kann man aus Steinen wertvolles Eisenerz herstellen."

// ---- do not change anything below this line ---

textwin print "/p"
